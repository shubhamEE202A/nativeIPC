/** Automatically generated file. DO NOT MODIFY */
package com.marakana.android.fibonaccicommon;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}